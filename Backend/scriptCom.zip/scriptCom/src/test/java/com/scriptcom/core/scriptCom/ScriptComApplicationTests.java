package com.scriptcom.core.scriptCom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScriptComApplicationTests {

	@Test
	void contextLoads() {
	}

}
