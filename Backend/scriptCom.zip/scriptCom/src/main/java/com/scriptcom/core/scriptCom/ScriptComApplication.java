package com.scriptcom.core.scriptCom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScriptComApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScriptComApplication.class, args);
	}

}
